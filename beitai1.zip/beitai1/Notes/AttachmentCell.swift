//
//  AttachmentCell.swift
//  Notes
//
//  Created by キラ on 2016/09/17.
//  Copyright © 2016年 Kira. All rights reserved.
//

import Cocoa

class AttachmentCell: NSCollectionViewItem {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
