//
//  AddAttachmentViewController.swift
//  Notes
//
//  Created by キラ on 2016/09/19.
//  Copyright © 2016年 Kira. All rights reserved.
//

import Cocoa

protocol AddAttachmentDelegate {
    
    func addFile()
    
}

class AddAttachmentViewController: NSViewController {
    var delegate : AddAttachmentDelegate?
    
    
    @IBAction func addFile(sender: AnyObject) {
        self.delegate?.addFile()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
