//
//  Document.swift
//  Notes
//
//  Created by キラ on 2016/09/05.
//  Copyright © 2016年 Kira. All rights reserved.
//

import Cocoa

extension NSFileWrapper {
    
    dynamic var fileExtension : String? {
        return self.preferredFilename?.componentsSeparatedByString(".").last
    }
    
    dynamic var thumbnailImage : NSImage {
        
        if let fileExtension = self.fileExtension {
            return NSWorkspace.sharedWorkspace().iconForFileType(fileExtension)
        } else {
            return NSWorkspace.sharedWorkspace().iconForFileType("")
        }
    }
    
    func conformsToType(type: CFString) -> Bool {
        
        // Get the extension of this file
        guard let fileExtension = self.fileExtension else {
            // If we can't get a file extension,
            // assume that it doesn't conform
            return false
        }
        
        // Get the file type of the attachment based on its extension
        guard let fileType = UTTypeCreatePreferredIdentifierForTag(
            kUTTagClassFilenameExtension, fileExtension, nil)?
            .takeRetainedValue() else {
                // If we can't figure out the file type
                // from the extension, it also doesn't conform
                return false
        }
        
        // Ask the system if this file type conforms to the provided type
        return UTTypeConformsTo(fileType, type)
    }
}


//Names of files/directories in the package
enum ErrorCode : Int{
    /// we could not find the document at all
    case CannotAccessDocument
    
    /// we could not find any file wrappers inside this document
    case CannotLoadFileWrappers
    
    /// we couldnt load the Text.rtf file
    case CannotLoadText
    
    /// we could not access the Attachments folder
    case CannotAccessAttachments
    
    /// we could not save the Text.rtf file.
    case CannotSaveText
    
    ///We couldnt save an attachment/
    case CannotSaveAttachment
}
enum NoteDocumentFileNames : String {
    case TextFile="Text.rtf"
    case AttachmentsDirectory="Attachments"
}
let ErrorDomain = "NotesErrorDomain"

func err(code: ErrorCode, _ userInfo:[NSObject:AnyObject]? = nil)
    -> NSError {
        // generate an nserror object, using errordomain and whatever
        //value we were passed
        return NSError(domain: ErrorDomain, code: code.rawValue, userInfo: userInfo)
}

class Document: NSDocument {
    var popover : NSPopover?
    @IBAction func addAttachment(sender: NSButton) {
        if let viewController = AddAttachmentViewController(
            nibName:"AddAttachmentViewController", bundle:NSBundle.mainBundle()
            ) {
            
            // BEGIN add_attachment_method_delegate
            viewController.delegate=self
            // END add_attachment_method_delegate
            
            self.popover = NSPopover()
            
            self.popover?.behavior = .Transient
            
            self.popover?.contentViewController = viewController
            
            self.popover?.showRelativeToRect(sender.bounds,
                                             ofView: sender, preferredEdge: NSRectEdge.MaxY)
        }

    }
    
    dynamic var attachedFiles : [NSFileWrapper]? {
        if let attachmentsFileWrappers =
            self.attachmentsDirectoryWrapper?.fileWrappers {
            
            let attachments = Array(attachmentsFileWrappers.values)
            
            return attachments
            
        } else {
            return nil
        }
    }

    func addAttachmentAtURL(url:NSURL) throws {
        
        guard attachmentsDirectoryWrapper != nil else {
            throw err(.CannotAccessAttachments)
        }
        
        self.willChangeValueForKey("attachedFiles")
        
        let newAttachment = try NSFileWrapper(URL: url,
                                              options: NSFileWrapperReadingOptions.Immediate)
        
        attachmentsDirectoryWrapper?.addFileWrapper(newAttachment)
        
        self.updateChangeCount(.ChangeDone)
        self.didChangeValueForKey("attachedFiles")
    }

    @IBOutlet weak var attachmentsList: NSCollectionView!
    // Main text content
    var text:NSAttributedString = NSAttributedString()
    var documentFileWrapper = NSFileWrapper(directoryWithFileWrappers: [:])
    private var attachmentsDirectoryWrapper : NSFileWrapper? {
        
        guard let fileWrappers = self.documentFileWrapper.fileWrappers else {
            NSLog("Attempting to access document's contents, but none found!")
            return nil
        }
        
        var attachmentsDirectoryWrapper =
            fileWrappers[NoteDocumentFileNames.AttachmentsDirectory.rawValue]
        
        if attachmentsDirectoryWrapper == nil {
            
            attachmentsDirectoryWrapper =
                NSFileWrapper(directoryWithFileWrappers: [:])
            
            attachmentsDirectoryWrapper?.preferredFilename =
                NoteDocumentFileNames.AttachmentsDirectory.rawValue
            
            self.documentFileWrapper.addFileWrapper(attachmentsDirectoryWrapper!)
        }
        
        return attachmentsDirectoryWrapper
    }

    override init() {
        super.init()
        // Add your subclass-specific initialization here.
    }
    
    override class func autosavesInPlace() -> Bool {
        return true
    }
    
    override var windowNibName: String? {
        // Returns the nib file name of the document
        // If you need to use a subclass of NSWindowController or if your document supports multiple NSWindowControllers, you should remove this property and override -makeWindowControllers instead.
        return "Document"
    }
    
    override func dataOfType(typeName: String) throws -> NSData {
        // Insert code here to write your document to data of the specified type. If outError != nil, ensure that you create and set an appropriate error when returning nil.
        // You can also choose to override fileWrapperOfType:error:, writeToURL:ofType:error:, or writeToURL:ofType:forSaveOperation:originalContentsURL:error: instead.
        throw NSError(domain: NSOSStatusErrorDomain, code: unimpErr, userInfo: nil)
    }
    
    override func readFromData(data: NSData, ofType typeName: String) throws {
        // Insert code here to read your document from the given data of the specified type. If outError != nil, ensure that you create and set an appropriate error when returning false.
        // You can also choose to override readFromFileWrapper:ofType:error: or readFromURL:ofType:error: instead.
        // If you override either of these, you should also override -isEntireFileLoaded to return false if the contents are lazily loaded.
        throw NSError(domain: NSOSStatusErrorDomain, code: unimpErr, userInfo: nil)
    }
    override func fileWrapperOfType(typeName: String) throws -> NSFileWrapper {
        let textRTFData = try self.text.dataFromRange(NSRange(0..<self.text.length), documentAttributes: [NSDocumentTypeDocumentAttribute: NSRTFTextDocumentType])
        //if the current document file wrapper already contains a text file, removeit and replace it with new one
        if let oldTextFileWrapper = self.documentFileWrapper.fileWrappers?[NoteDocumentFileNames.TextFile.rawValue] {
            self.documentFileWrapper.removeFileWrapper(oldTextFileWrapper)
        }
        //save the text data into fuke
        self.documentFileWrapper.addRegularFileWithContents(
            textRTFData,
            preferredFilename: NoteDocumentFileNames.TextFile.rawValue
        )
        return self.documentFileWrapper
    }
    override func readFromFileWrapper(fileWrapper: NSFileWrapper, ofType typeName: String) throws {
        guard let fileWrappers=fileWrapper.fileWrappers else{
            throw err(.CannotLoadFileWrappers)
        }
        
        guard let documentsTextData =
            fileWrappers[NoteDocumentFileNames.TextFile.rawValue]?
                .regularFileContents else{
                    throw err(.CannotLoadText)
        }
        
        guard let documentText=NSAttributedString(RTF:documentsTextData,documentAttributes: nil)
            else{
                throw err(.CannotLoadText)
        }
        self.documentFileWrapper=fileWrapper
        self.text=documentText
    }
    
    
}
extension Document : AddAttachmentDelegate {
    
    // BEGIN document_addattachmentdelegate_extension_impl
    // BEGIN add_file
    func addFile() {
        
        let panel = NSOpenPanel()
        
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        
        panel.beginWithCompletionHandler { (result) -> Void in
            if result == NSModalResponseOK,
                let resultURL = panel.URLs.first {
                
                do {
                    // We were given a URL - copy it in!
                    try self.addAttachmentAtURL(resultURL)
                    
                    // Refresh the attachments list
                    self.attachmentsList?.reloadData()
                    
                } catch let error as NSError {
                    
                    // There was an error adding the attachment.
                    // Show the user!
                    
                    // Try to get a window to present a sheet in
                    if let window = self.windowForSheet {
                        
                        // Present the error in a sheet
                        NSApp.presentError(error,
                            modalForWindow: window,
                            delegate: nil,
                            didPresentSelector: nil,
                            contextInfo: nil)
                        
                        
                    } else {
                        // No window, so present it in a dialog box
                        NSApp.presentError(error)
                    }
                }
            }
        }
        
        
    }
    // END add_file
    // END document_addattachmentdelegate_extension_impl
}
extension Document : NSCollectionViewDataSource {
    
    // BEGIN collectionview_datasource_numberofitems
    func collectionView(collectionView: NSCollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        
        // The number of items is equal to the number of
        // attachments we have. If for some reason we can't
        // access attachedFiles, we have zero items.
        return self.attachedFiles?.count ?? 0
    }
    // END collectionview_datasource_numberofitems
    
    // BEGIN collectionview_datasource_item
    func collectionView(collectionView: NSCollectionView,
                        itemForRepresentedObjectAtIndexPath indexPath: NSIndexPath)
        -> NSCollectionViewItem {
            
            // Get the attachment that this cell should represent
            let attachment = self.attachedFiles![indexPath.item]
            
            // Get the cell itself
            let item = collectionView
                .makeItemWithIdentifier("AttachmentCell", forIndexPath: indexPath)
                as! AttachmentCell
            
            // Display the image and file extension in the ecell
            item.imageView?.image = attachment.thumbnailImage
            item.textField?.stringValue = attachment.fileExtension ?? ""
            
            // BEGIN collectionview_datasource_item_delegate
            // Make this cell use us as its delegate
            //item.delegate = self
            // END collectionview_datasource_item_delegate
            
            return item
    }
    // END collectionview_datasource_item
    
}
